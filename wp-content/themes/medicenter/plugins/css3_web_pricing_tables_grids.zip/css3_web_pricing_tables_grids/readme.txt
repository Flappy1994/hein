---Instalation---
1. Login into your WordPress admin panel.
2. Go to Admin Panel->Plugins->Add New->Upload
3. Select codecanyon-629172-css3-web-pricing-tables-grids-for-wordpress.zip file
4. Activate plugin
5. In Settings submenu you'll find CSS3 Web Pricing Tables Grids position to manage plugin.
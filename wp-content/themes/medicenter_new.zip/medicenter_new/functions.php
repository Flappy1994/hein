/**
* Enqueue scripts and styles
*/
function medicenter_new_scripts()
{
    wp_enqueue_style( 'medicenter_new-style', get_stylesheet_uri() );

    wp_enqueue_script( 'medicenter_new-navigation', get_template_directory_uri());


}
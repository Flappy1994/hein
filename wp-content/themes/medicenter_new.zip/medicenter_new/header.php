<!DOCTYPE html>
<html <?php language_attributes();?>>
    <head>
        <title><?php bloginfo('name'); ?> | <?php is_home() || is_front_page() ? bloginfo('description') : wp_title(''); ?></title>
        <!-- Meta Tags-->
        <meta charset="<?php bloginfo("charset"); ?>" />
		<meta name="generator" content="WordPress <?php bloginfo("version"); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="description" content="<?php bloginfo('description'); ?>" />
		<meta name="format-detection" content="telephone=no" />
        <!-- StyleSheets -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <?php wp_head(); ?>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg">
            <a class="navbar brand" href="#">Home</a>
        </nav>

    

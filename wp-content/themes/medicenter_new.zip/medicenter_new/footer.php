<?php global $theme_options, $themename; ?>
			<div class="footer_container">
				<div class="footer">
					<ul class="footer_banner_box_container clearfix">
						<?php
						$sidebar = get_post(get_post_meta(get_the_ID(), "page_sidebar_footer_top", true));
						if(!(int)get_post_meta($sidebar->ID, "hidden", true) && is_active_sidebar($sidebar->post_name))
							dynamic_sidebar($sidebar->post_name);
						?>
					</ul>
					<div class="footer_box_container clearfix">
						<?php
						$sidebar = get_post(get_post_meta(get_the_ID(), "page_sidebar_footer_bottom", true));
						if(!(int)get_post_meta($sidebar->ID, "hidden", true) && is_active_sidebar($sidebar->post_name))
							dynamic_sidebar($sidebar->post_name);
						?>
					</div>
					<?php if($theme_options["footer_text_left"]!="" || $theme_options["footer_text_right"]!=""): ?>
					<div class="copyright_area clearfix">
						<?php if($theme_options["footer_text_left"]!=""): ?>
						<div class="copyright_left">
							<?php echo do_shortcode($theme_options["footer_text_left"]); ?>
						</div>
						<?php 
						endif;
						if($theme_options["footer_text_right"]!=""): ?>
						<div class="copyright_right">
							<?php echo do_shortcode($theme_options["footer_text_right"]); ?>
						</div>
						<?php endif; ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
		if((int)$theme_options["layout_picker"])
			mc_get_theme_file("/layout_picker/layout_picker.php");		
		wp_footer();
		?>
       
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    </body>
    </html>